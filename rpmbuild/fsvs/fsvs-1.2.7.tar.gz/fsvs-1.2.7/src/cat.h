/************************************************************************
 * Copyright (C) 2005-2008 Philipp Marek.
 *
 * This program is free software;  you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 ************************************************************************/

#ifndef __CACHE_H__
#define __CACHE_H__


/** \file
 * \ref cat action header file. */

work_t cat__work;

#endif

