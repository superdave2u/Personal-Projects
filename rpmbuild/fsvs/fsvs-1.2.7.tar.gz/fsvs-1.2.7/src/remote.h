/************************************************************************
 * Copyright (C) 2007-2008 Philipp Marek.
 *
 * This program is free software;  you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 ************************************************************************/

#ifndef __REMOTE_H__
#define __REMOTE_H__

/** \file
 * \ref remote-status header file.
 *
 * Currently empty, as it's the same as an update - without getting the 
 * files' contents and changing local data. */

#endif

